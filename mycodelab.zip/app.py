
from flask import Flask, render_template, request, send_file, redirect, url_for
import os

app = Flask(__name__)

UPLOAD_FOLDER = 'static/uploads'
JAVA_FOLDER = os.path.join(UPLOAD_FOLDER, 'java')
PYTHON_FOLDER = os.path.join(UPLOAD_FOLDER, 'python')
STUDY_MATERIAL_FOLDER = os.path.join(UPLOAD_FOLDER, 'study_materials')

os.makedirs(JAVA_FOLDER, exist_ok=True)
os.makedirs(PYTHON_FOLDER, exist_ok=True)
os.makedirs(STUDY_MATERIAL_FOLDER, exist_ok=True)

app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

java_samples = [
    {"name": "HelloWorld.java", "code": "public class HelloWorld {\n    public static void main(String[] args) {\n        System.out.println(\"Hello, World!\");\n    }\n}"},
    {"name": "Factorial.java", "code": "public class Factorial {\n    public static void main(String[] args) {\n        int n = 5, fact = 1;\n        for(int i = 1; i <= n; i++) fact *= i;\n        System.out.println(\"Factorial: \" + fact);\n    }\n}"}
]

python_samples = [
    {"name": "hello_world.py", "code": "print('Hello, World!')"},
    {"name": "factorial.py", "code": "def factorial(n):\n    return 1 if n == 0 else n * factorial(n-1)\nprint(factorial(5))"}
]

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/java', methods=['GET', 'POST'])
def java():
    if request.method == 'POST':
        file = request.files['file']
        if file and file.filename.endswith('.java'):
            file.save(os.path.join(JAVA_FOLDER, file.filename))
    files = os.listdir(JAVA_FOLDER)
    return render_template('java.html', samples=java_samples, uploaded_files=files)

@app.route('/python', methods=['GET', 'POST'])
def python():
    if request.method == 'POST':
        file = request.files['file']
        if file and file.filename.endswith('.py'):
            file.save(os.path.join(PYTHON_FOLDER, file.filename))
    files = os.listdir(PYTHON_FOLDER)
    return render_template('python.html', samples=python_samples, uploaded_files=files)

@app.route('/study_material', methods=['GET', 'POST'])
def study_material():
    if request.method == 'POST':
        file = request.files['file']
        if file and file.filename.endswith(('.pdf', '.txt')):
            file.save(os.path.join(STUDY_MATERIAL_FOLDER, file.filename))
    files = os.listdir(STUDY_MATERIAL_FOLDER)
    return render_template('study_material.html', uploaded_files=files)

@app.route('/download/<folder>/<filename>')
def download_file(folder, filename):
    folder_path = os.path.join(UPLOAD_FOLDER, folder)
    return send_file(os.path.join(folder_path, filename), as_attachment=True)

if __name__ == '__main__':
    app.run(debug=True)
